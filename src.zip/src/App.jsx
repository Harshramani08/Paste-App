import React from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Navbar from './navComponents/Navbar'
import Home from './navComponents/Home'
import Paste from './navComponents/Paste'
import ViewPaste from './navComponents/ViewPaste'

const App = () => {
  const router = createBrowserRouter([
    {
      path: "/",
      element: (
        <div className="flex flex-col h-screen bg-gray-900 text-white">
          <Navbar />
          <div className="flex-1 flex justify-center items-start pt-10">
            <Home />
          </div>
        </div>
      )
    },
    {
      path: "/pastes",
      element: (
        <div className="flex flex-col h-screen bg-gray-900 text-white">
          <Navbar />
          <div className="flex-1 flex justify-center items-start pt-10">
            <Paste />
          </div>
        </div>
      )
    },
    {
      path: "/pastes/:id",
      element: (
        <div className="flex flex-col h-screen bg-gray-900 text-white">
          <Navbar />
          <div className="flex-1 flex justify-center items-start pt-10">
            <ViewPaste />
          </div>
        </div>
      )
    },
  ])

  return (
    <RouterProvider router={router} />
  )
}

export default App
